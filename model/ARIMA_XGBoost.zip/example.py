'''範例'''
import pandas as pd
import arima_mix_xgboost

# 讀取數據
data = pd.read_excel('data_CT12000.xlsx', parse_dates=['date'], index_col='date')

# 建立模型
model = arima_mix_xgboost.ARIMAXGBoostModel(data)

# 訓練模型
model.train_model()

# 預測未來 3 個月
future_prediction = model.predict_future()

# 輸出預測結果
print(future_prediction)
